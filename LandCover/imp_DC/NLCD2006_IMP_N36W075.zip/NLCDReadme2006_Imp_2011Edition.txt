National Land Cover Database (NLCD) Tiled Data Distribution SYstem (TDDS) Zipfile Content Readme

Table of Contents


INTRODUCTION
Process Description
Part 1: Data Specification
PART 2: TILED DATA DISTRIBUTION SYSTEM (TDDS) - ORTHOIMAGERY INFORMATION
Part 3: FILE NAMING CONVENTION
PART 4: CONTENTS OF ZIPFILE
PART 5: DISTRIBUTION INFORMATION
Part 6: Resource Information

Introduction
The National Land Cover Database products are created through a cooperative project conducted by the Multi-Resolution Land Characteristics (MRLC) Consortium.  The MRLC Consortium is a partnership of federal agencies (www.mrlc.gov), consisting of the U.S. Geological Survey (USGS), the National Oceanic and Atmospheric Administration (NOAA), the U.S. Environmental Protection Agency (EPA), the U.S. Department of Agriculture (USDA), the U.S. Forest Service (USFS), the National Park Service (NPS), the U.S. Fish and Wildlife Service (FWS), the Bureau of Land Management (BLM) and the USDA Natural Resources Conservation Service (NRCS).  Previously, NLCD consisted of three major data releases based on a 10-year cycle.  These include a circa 1992 conterminous U.S. land cover dataset with one thematic layer (NLCD 1992), a circa 2001 50-state/Puerto Rico updated U.S. land cover database (NLCD 2001 2011 Edition) with three layers including thematic land cover, percent imperviousness, and percent tree canopy, and a 1992/2001 Land Cover Change Retrofit Product.  With these national data layers, there is often a 5-year time lag between the image capture date and product release.  In some areas, the land cover can undergo significant change during production time, resulting in products that may be perpetually out of date.  To address these issues, this circa 2006 NLCD land cover product (NLCD 2006 2011 Edition) was conceived to meet user community needs for more frequent land cover monitoring (moving to a 5-year cycle) and to reduce the production time between image capture and product release.  NLCD 2006 (2011 edition) is designed to provide the user both updated land cover data and additional information that can be used to identify the pattern, nature, and magnitude of changes occurring between 2001 (2011 Edition) and 2006 (2011 Edition) for the conterminous United States at medium spatial resolution.

        For NLCD 2006 (2011 Edition), there are 4 primary data products:  1) NLCD 2006 Land Cover (2011 Edition); 2) NLCD 2001/2006 Land Cover Change Pixels (2011 Edition) labeled with the 2006 land cover class; 3) NLCD 2006 Percent Developed Imperviousness (2011 Edition); and 4) NLCD 2001/2006 Percent Developed Imperviousness Change (2011 Edition).  In addition, ancillary metadata includes the NLCD 2006 Path/Row Index vector file showing the footprint of Landsat scene pairs used to derive 2001/2006 spectral change with change pair acquisition dates included in the attribute table.  Also, as part of the NLCD 2011 project, NLCD 2001 data products have been revised and reissued (2011 Edition) to provide full compatibility with all other NLCD 2011 Edition products.

        Land cover maps, derivatives and all associated documents are considered "provisional" until a formal accuracy assessment can be conducted.  The NLCD 2006 is created on a path/row basis and mosaicked to create a seamless national product.  Questions about the NLCD 2006 land cover product can be directed to the NLCD 2006 land cover mapping team at the USGS/EROS, Sioux Falls, SD (605) 594-6151 or mrlc@usgs.gov.


Process Description
 Original NLCD 2006 processing is described in this process step.  Changes made to NLCD 2006 products to maintain compatibility and alignment with NLCD 2001 (2011 Edition) and NLCD 2011 (2011 Edition) are described in the second process step.

          Original NLCD 2006 Processing - Landsat image selection and preprocessing.  For the change analysis, a two-date pair of Landsat scenes was selected for each path/row restricting temporal range to reduce the impact of seasonal and phenological variation.  A pre-processing step was performed to convert the digital number to top of atmosphere reflectance using procedures similar to those established for the NLCD 2001 mapping effort (Homer et al., 2004).  Reflectance derivatives, including a tasseled-cap transformation and a 3-ratio index, were generated for each scene to use in the modeling process as independent variables.  Where present, clouds and cloud shadows were digitized for masking.

          NLCD 2006 Percent Developed Imperviousness (Final Product) and Percent Developed Imperviousness Change Analysis.  Because the four NLCD developed classes are derived from a percent imperviousness mapping product, an overview of steps required to update the NLCD 2001 imperviousness to reflect urban growth captured in 2006 era Landsat imagery is provided here (Xian et al., 2010).  First, 2001 nighttime lights imagery from the NOAA Defense Meteorological Satellite Program (DMSP) was imposed on the NLCD 2001 impervious surface product to exclude low density imperviousness outside urban and suburban centers so that only imperviousness in urban core areas would be used in the training dataset. Two training datasets, one having a relatively larger urban extent and one having a smaller extent, were produced through imposing two different thresholds on city light imagery. Second, each of the two training datasets combined with 2001 Landsat imagery was separately applied using a regression tree (RT) algorithm to build up RT models. Two sets of RT models were then used to estimate percent imperviousness and to produce two 2001 synthetic impervious surfaces. Similarly, the same two training datasets were used with 2006 Landsat imagery to create two sets of RT models that produce two 2006 synthetic impervious surfaces. Third, the 2001 and 2006 synthetic impervious surface pairs were compared using both 2001 impervious surface products to retain 2001 impervious surface area (ISA) in the unchanged areas. The 2006 DMSP nighttime lights imagery was then employed to ensure that non-imperviousness areas were not included and that new impervious surfaces emerged in the city light extent. After this step, two 2006 intermediate impervious surfaces were produced. Finally, the two intermediate products and 2001 imperviousness were compared to remove false estimates in non-urban areas and generate a 2006 impervious surface estimate.  Imperviousness threshold values used to derive the NLCD developed classes are: (1) developed open space (imperviousness < 20%), (2) low-intensity developed (imperviousness from 20 - 49%), (3) medium intensity developed (imperviousness from 50 -79%), and (4) high-intensity developed (imperviousness > 79%).  During this process, inconsistencies in the NLCD 2001 Percent Developed Imperviousness product were corrected with the new product, NLCD 2001 Percent Developed Imperviousness Version 2.0, included as part of the NLCD 2006 product release.

          Land Cover Change Analysis.  For the NLCD 2006 Land Cover Update, a new change detection method, Multi-Index Integrated Change Analysis (MIICA), was developed to capture a full range of land cover disturbance and potential land cover change patterns for updating the National Land Cover Database (Jin et al., 2013). Recognizing the potential complementary nature of multiple spectral indices in detection of different land cover changes, we integrated four indices into one model to more accurately detect true land cover changes between two time periods.  Within the model, normalized burn ratio (NBR), change vector (CV, Xian et al., 2009), relative change vector (RCV), and normalized difference vegetation index (NDVI) are calculated separately for the early date (circa 2001) and late date (circa 2006) scenes.  The four pairs of indices for the two dates are differenced and then evaluated in a final model conditional statement that categorizes each pixel as either biomass increase, biomass decrease, or no change.  Individual path/row raw results from this change analysis process are assembled into a seamless national product to form the NLCD 2001/2006 Maximum Potential Change map.  The integrated change result is clumped and sieved to produce a refined change/no-change mask used below.

          NLCD 2006 Land Cover Classification.  Land cover mapping protocols used during NLCD 2006 processing are similar to those used to label the NLCD 2001 product (Homer et al., 2004), but applied on a path/row basis instead of multiple path/row MRLC zones (Xian et al., 2009).  Classification was achieved using decision tree modeling that employed a combination of Landsat imagery, reflectance derivatives, and ancillary data (independent variables) with training data points (dependent variable) collected from a refined version of the NLCD 2001 land cover product.  Training points were randomly sampled and limited to those areas that were determined to be unchanged between 2001 and 2006 during the MIICA spectral change analysis process.  Training data for pixels changed to developed land cover were not collected since the four classes in urban and sub-urban areas were mapped separately using a regression tree modeling method (described in the Imperviousness Change Analysis process steps above).  Post classification modeling and hand-editing were used to further refine the decision tree output.  Following classification, the 2006 land cover was masked with the change/no-change result (captured during the MIICA change analysis modeling) to extract a label for spectrally changed pixels.  Labeled change pixels were then compared to the NLCD 2001 land cover base to exclude those pixels identified as spectral change, but classified with the same label as the corresponding 2001 pixel.  NLCD 2006 percent developed impervious pixels, identified as changed, were extracted to NLCD developed class codes using NLCD 2001 legend thresholds for developed classes and added to the change pixel map.  This intermediate change pixel product was generalized using the NLCD Smart Eliminate tool with the following minimum mapping units (mmu) applied:  1 acre (approximately 5 ETM+ 30 m  pixel patch) for developed classes (class codes 21, 22, 23, and 24); 7.12 acres (approximately 32 ETM+ pixel patch) for agricultural classes (class codes 81 and 82); and 2.67 acres (approximately 12 ETM+ pixel patch) for all other classes (class codes 11, 12, 31, 41, 42, 43, 52, 71, 90, and 95).  The smart eliminate aggregation program subsumes pixels from the single pixel level to the mmu pixel patch using a queens algorithm at doubling intervals. The algorithm consults a weighting matrix to guide merging of cover types by similarity, resulting in a product that preserves land cover logic as much as possible.  During the NLCD 2006 analysis and modeling process, inconsistencies in the NLCD 2001 Land cover product were corrected with the new product, NLCD 2001 Land Cover Version 2.0, included as part of the NLCD 2006 product release.

          NLCD 2006 Land Cover (Final Product).  Additional processing steps were designed to create the final NLCD 2006 land cover map.  Individual path/row change pixel results were assembled to form an intermediate seamless national product.  This seamless change pixel map was reviewed and edited to remove regional inconsistencies.  Refined NLCD 2006 change pixels were then combined with the re-issued NLCD 2001 Land Cover Version 2.0, and the resulting image was smart-eliminated to a 5-pixel mmu.  This final step eliminated single pixels and patches less than 5 pixels in extent that appeared as a result of combining the separate images.

          NLCD 2006 Change Pixels (Final Product).  A comparison of the NLCD 2001 re-issued base and the NLCD 2006 Land Cover was necessary to extract a final version of the NLCD 2006 Change Pixels.  In a model, pixels that were labeled with the same land cover class code were removed and only those pixels that did not agree in the two classifications were retained as final NLCD 2006 Change Pixels.

          NLCD 2001/2006 Percent Developed Imperviousness Change (Supplementary Raster Layer).  The NLCD 2001 Percent Developed Imperviousness Version 2.0 and the NLCD 2006 Percent Developed Imperviousness were compared in a model to provide the user community with a layer that highlights imperviousness change between 2001 and 2006.

          Landsat data and ancillary data used for the land cover prediction -

          For a list of Landsat scenes and scene dates by path/row used in this project, please see:  appendix1_nlcd2006_scene_list_by_path_row.txt

          Data Type of DEM composed of 1 band of Continuous Variable Type.

          Data Type of Slope composed of 1 band of Continuous Variable Type.

          Data Type of Aspect composed of 1 band of Categorical Variable Type.

          Data type of Position Index composed of 1 band of Continuous Variable Type.

          Data type of 3-ratio index composed of 3 bands of Continuous Variable Type.
      

NLCD 2006 (2011) Edition Processing Steps - To improve NLCD imperviousness the 2011 project included a process to reduce omission and commission error in NLCD 2001, 2006, and 2011 products.  This activity was completed for urban areas in most of the eastern � of the conterminous United States.  High resolution (one-meter ground sample distance) National Aerial Imagery Program (NAIP � http://fsa.usda.gov/FSA/) imagery was used to verify imperviousness.  Using hand-edits imperviousness was removed from areas incorrectly identified as developed and added to areas where developed land cover was missed.  A modeling process was implemented to add missed imperviousness changes to the correct era and to fill areas where developed was removed with an appropriate non-developed land cover class.  These improvements were incorporated with the derived developed classes in all areas of imperviousness and land cover versions released with NLCD 2011 editions.
PART 1: Data Specifications and Products


	Resolution:      	one Arc Second (~30 meter)
  	Data type:      	GeoTIFF
  	Projection:  		Albers Conical Equal Area
  	Datum:       		NAD83
  	

	NLCD 2006 - Imperviousness  - 2011 Edition includes data for Conterminous U.S..  
	

PART 2: TILED DATA DISTRIBUTION SYSTEM (TDDS) - NLCD INFORMATION

Tiled Data Distribution System (TDDS) is a means to access pre-packaged data.  Each 2001 NLCD product are cut to 3 x 3 degree tiles and zipped for online download.  The zip bundles contain the product image and associated files, an overall coverage shapefile, metadata, color table file, appendix of scene listings, and readme.  The data is available for download thru The National Map viewer and MRLC viewer.  (http://viewer.nationalmap.gov/viewer/ and http://gisdata.usgs.gov/website/mrlc/viewer.htm)

Part 3: FILE NAMING CONVENTION

Each tile is cut to a 3 x 3 degree area.  The naming convention for each tile is the NLCD product and lower right corner coordinate. 


The file naming convention is:
	
        NLCDFFFF_NNN_aaaaaa

		NLCD      =  National Land Cover Database
		FFFF      =  Project Year (2006)
                NNN       =  Product type (LC = Landcover, IMP = Imperviousness
		aaaaaa    =  Lower right corner coordinate (N24W078) 		


  	Example: NLCD2006_IMP_N24W078.zip 

			NLCD     =  National Land Cover Database
	 		2006     =  Project year 2006
		      	IMP       =  Imperviousness product
                        N24W078  =  Tile extent starts at the lower right corner coodinate of N 					24 and W 78. The data covers an area within N 24, N 27, 
					W 78, W 81  
                        			           

PART 4: CONTENTS OF ZIPFILE

	
	.tif  	 =  Geotiff image
	.tfw	 =  World file for full resolution Geotiff image
	.aux.xm l=  diplay info
	.prj	 =  Projection File
	.jpg	 =  Lossy compressed image
	.jpw     =  World file for lossy compressed image
	.xml     =  FGDC Metadata file 
	.htm     =  HTML format FGDC metadata file suitable for reading and printing
	.vat.dbf =  Color table information
	Shapefile
	 (.dbf, .prj, .sbn, .sbx, .shp, .shx)
		=  The shapefile (consisting of 6 files) represents the overall 3 x 3 degree GRID 
	NLCDReadme2006_Imp_2011Edition.txt 
		=  The readme text file
	Appendix
		=  List of Landsat scenes and scene dates by path/row used in this project


PART 5: DISTRIBUTION INFORMATION

	Access points (i.e. map interface) can be found at:
		
		http://viewer.nationalmap.gov/viewer/ and http://gisdata.usgs.gov/website/mrlc/viewer.htm
	
	To acquire entire datasets via Bulk Data Distribution, they can be found at:
	
		http://www.mrlc.gov/


Part 6: Resource Information

Information concerning the Multi-Resolution Land Characteristics Consortium  (MRLC), data info, and refernces can be found at:
	
		http://www.mrlc.gov/



Disclaimer:  Any use of trade, product, or firm names is for descriptive 
purposes only and does not imply endorsement by the U. S. Government.    


Readme Publication Date:  May 2014


